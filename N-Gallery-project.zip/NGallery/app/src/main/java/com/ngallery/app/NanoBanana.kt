package com.ngallery.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Nano Banana = Gemini's native image generation / editing model. */
object NanoBanana {
    const val DEFAULT_MODEL = "gemini-2.5-flash-image"

    suspend fun edit(apiKey: String, model: String, source: Bitmap, prompt: String): Result<Bitmap> =
        withContext(Dispatchers.IO) {
            runCatching {
                val img = scaleDown(source, 1536)
                val baos = ByteArrayOutputStream()
                img.compress(Bitmap.CompressFormat.JPEG, 92, baos)
                val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)

                val body = JSONObject().put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray()
                                .put(JSONObject().put("text", prompt))
                                .put(
                                    JSONObject().put(
                                        "inline_data",
                                        JSONObject().put("mime_type", "image/jpeg").put("data", b64)
                                    )
                                )
                        )
                    )
                )

                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 30_000
                    readTimeout = 180_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", apiKey)
                }
                conn.outputStream.use { it.write(body.toString().toByteArray()) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) error(parseError(code, text))

                val json = JSONObject(text)
                val parts = json.optJSONArray("candidates")
                    ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")

                var bmp: Bitmap? = null
                var note = ""
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val p = parts.getJSONObject(i)
                        val inline = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                        if (inline != null) {
                            val bytes = Base64.decode(inline.getString("data"), Base64.DEFAULT)
                            bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        } else if (p.has("text")) {
                            note = p.getString("text")
                        }
                    }
                }
                if (bmp != null) bmp
                else {
                    val block = json.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
                    error(
                        when {
                            note.isNotBlank() -> "Model ne image nahi di: ${note.take(160)}"
                            block.isNotBlank() -> "Request block hui: $block"
                            else -> "Model ne koi image return nahi ki"
                        }
                    )
                }
            }
        }

    private fun parseError(code: Int, body: String): String {
        val msg = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrNull()
        return "API error $code: ${(msg ?: body).take(200)}"
    }

    private fun scaleDown(b: Bitmap, max: Int): Bitmap {
        val s = maxOf(b.width, b.height)
        if (s <= max) return b
        val f = max.toFloat() / s
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }
}
