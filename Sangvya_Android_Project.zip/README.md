# Sangvya (Android MVP)

A dark, offline-first Android starter project with:
- Bluetooth LE nearby discovery (phones advertise a shared service UUID)
- Approximate proximity estimate from BLE RSSI
- Local vibration/toast alert when a detected peer crosses the chosen threshold
- Local GPS coordinates display
- GitHub Actions workflow to build and upload a debug APK

## Build on GitHub
1. Create a GitHub repository.
2. Upload the **contents** of this ZIP (so `app/` and `.github/` are at repository root).
3. Open Actions. The workflow builds `app-debug.apk` and publishes it under Artifacts.
4. Install the debug APK on 2+ Android phones, grant Bluetooth and location permissions, and tap START NEARBY on each.

## Important limitations of this MVP
- BLE RSSI distance is an estimate, not precise ranging. Walls, phone orientation, device hardware and interference can make it inaccurate. Thresholds such as 5–10 m may fluctuate.
- This first build discovers nearby phones that are running the same app. It does **not** yet implement secure group invitations/group IDs, peer-to-peer chat, Wi-Fi Direct transport, remote location relay, or an online map. Those need a second implementation phase and, for remote live location, a backend/service.
- GPS coordinates are shown on the current phone only. When a peer leaves Bluetooth range, its latest location cannot be refreshed offline.
- This MVP is foreground-only. Android may pause scanning when the app is backgrounded or the screen is off. Production background alerts need a foreground service and notification, with additional platform permission handling.
- Use only with the consent of all friends. Location is sensitive; do not use covert tracking.

## Technical
- Kotlin, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26, JDK 17.

## Branding
The app display name and launcher icon use the supplied Sangvya logo.
