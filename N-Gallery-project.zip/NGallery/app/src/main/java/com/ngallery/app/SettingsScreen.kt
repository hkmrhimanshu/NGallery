package com.ngallery.app

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: GalleryViewModel, onClose: () -> Unit) {
    var key by remember { mutableStateOf(vm.prefs.apiKey) }
    var model by remember { mutableStateOf(vm.prefs.model) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BounceIcon(Icons.Outlined.ArrowBack, onClick = onClose)
            Text("Settings", fontFamily = Serif, fontSize = 32.sp, color = Color.White)
        }
        Text(
            "AI (Nano Banana / Gemini image)",
            color = Color.White,
            fontSize = 18.sp,
            modifier = Modifier.padding(top = 24.dp, bottom = 8.dp),
        )
        Text(
            "AI Eraser, Replace, Background aur AI Edit ke liye Google AI Studio ka API key chahiye " +
                "(aistudio.google.com/apikey). Key sirf is phone me save hoti hai.",
            color = Color(0xFF9A9A9A),
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 16.dp),
        )
        OutlinedTextField(
            value = key,
            onValueChange = { key = it; vm.prefs.apiKey = it.trim() },
            label = { Text("Gemini API key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = model,
            onValueChange = { model = it; vm.prefs.model = it.trim() },
            label = { Text("Model name") },
            singleLine = true,
            supportingText = {
                Text("Default: ${NanoBanana.DEFAULT_MODEL}. Naya image model aaye to yahan naam badal sakte ho.")
            },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        )
    }
}
