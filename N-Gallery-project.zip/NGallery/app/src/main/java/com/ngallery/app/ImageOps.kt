package com.ngallery.app

import android.content.ContentValues
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.net.Uri
import android.provider.MediaStore
import kotlin.math.abs
import kotlin.math.pow

data class EditState(
    val bitmap: Bitmap,
    val exposure: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f,
)

/** 4x5 colour matrix (Android layout) for the adjustment sliders. */
fun EditState.matrixArray(): FloatArray {
    val m = ColorMatrix()
    m.setSaturation((1f + saturation).coerceAtLeast(0f))
    val c = 1f + contrast * 0.6f
    val t = (1f - c) * 127.5f
    m.postConcat(
        ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    )
    val g = 2f.pow(exposure)
    val w = warmth * 0.25f
    m.postConcat(
        ColorMatrix(
            floatArrayOf(
                g * (1f + w), 0f, 0f, 0f, 0f,
                0f, g, 0f, 0f, 0f,
                0f, 0f, g * (1f - w), 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    )
    return m.array
}

fun decodeBitmap(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = runCatching {
    val src = ImageDecoder.createSource(ctx.contentResolver, uri)
    ImageDecoder.decodeBitmap(src) { dec, info, _ ->
        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = maxOf(info.size.width, info.size.height)
        if (s > maxSide) {
            val f = maxSide.toFloat() / s
            dec.setTargetSize((info.size.width * f).toInt(), (info.size.height * f).toInt())
        }
    }
}.getOrNull()

fun renderFinal(s: EditState): Bitmap {
    val out = Bitmap.createBitmap(s.bitmap.width, s.bitmap.height, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix(s.matrixArray()))
    }
    Canvas(out).drawBitmap(s.bitmap, 0f, 0f, paint)
    return out
}

fun rotateBitmap(b: Bitmap, degrees: Float): Bitmap {
    val m = Matrix().apply { postRotate(degrees) }
    return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
}

fun flipBitmap(b: Bitmap): Bitmap {
    val m = Matrix().apply { preScale(-1f, 1f) }
    return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
}

private fun strokePath(pts: List<PointF>, scale: Float): Path {
    val p = Path()
    if (pts.isEmpty()) return p
    p.moveTo(pts[0].x * scale, pts[0].y * scale)
    if (pts.size == 1) {
        p.lineTo(pts[0].x * scale + 0.1f, pts[0].y * scale)
    } else {
        for (i in 1 until pts.size) p.lineTo(pts[i].x * scale, pts[i].y * scale)
    }
    return p
}

/** Copy of [base] with the user's brush strokes painted bright red (this is what the model sees). */
fun drawMarks(base: Bitmap, strokes: List<List<PointF>>, scale: Float, brushDisplayPx: Float): Bitmap {
    val out = base.copy(Bitmap.Config.ARGB_8888, true) ?: base
    val canvas = Canvas(out)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = brushDisplayPx * scale
        color = Color.RED
    }
    strokes.forEach { canvas.drawPath(strokePath(it, scale), paint) }
    return out
}

/**
 * Keeps the original pixels everywhere except under the (feathered) brush mask,
 * where the AI result is blended in. Falls back to the plain AI result if the
 * model changed the aspect ratio.
 */
fun compositeMasked(
    base: Bitmap,
    result: Bitmap,
    strokes: List<List<PointF>>,
    scale: Float,
    brushDisplayPx: Float,
): Bitmap {
    val w = base.width
    val h = base.height
    val ratioBase = w.toFloat() / h
    val ratioRes = result.width.toFloat() / result.height
    if (abs(ratioBase - ratioRes) > 0.02f) return result

    val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val lc = Canvas(layer)
    lc.drawBitmap(result, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))

    val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val mc = Canvas(mask)
    val bw = brushDisplayPx * scale
    val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = bw * 1.15f
        color = Color.WHITE
        maskFilter = BlurMaskFilter((bw * 0.25f).coerceAtLeast(1f), BlurMaskFilter.Blur.NORMAL)
    }
    strokes.forEach { mc.drawPath(strokePath(it, scale), maskPaint) }

    lc.drawBitmap(mask, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })

    val out = base.copy(Bitmap.Config.ARGB_8888, true) ?: return result
    Canvas(out).drawBitmap(layer, 0f, 0f, null)
    return out
}

fun saveToGallery(ctx: Context, bmp: Bitmap): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "NG_${System.currentTimeMillis()}.jpg")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/N Gallery")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val resolver = ctx.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    resolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    values.clear()
    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
    resolver.update(uri, values, null, null)
    return uri
}
