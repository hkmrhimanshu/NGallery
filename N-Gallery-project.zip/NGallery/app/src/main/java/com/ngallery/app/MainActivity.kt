package com.ngallery.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
        )
        setContent { NTheme { Root() } }
    }
}

sealed interface Overlay {
    data class Viewer(val list: List<Media>, val index: Int) : Overlay
    data class Editor(val media: Media) : Overlay
    data class Collection(val title: String, val list: List<Media>) : Overlay
    data object Settings : Overlay
}

@Composable
fun Root(vm: GalleryViewModel = viewModel()) {
    val ctx = LocalContext.current
    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    var granted by remember {
        mutableStateOf(perms.all {
            ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
        })
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { r -> granted = r.values.all { it } }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }
    LaunchedEffect(granted) { if (granted) vm.refresh() }

    if (granted) {
        AppNav(vm)
    } else {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("N Gallery", fontFamily = Serif, fontSize = 40.sp, color = Color.White)
            Text(
                "Photos aur videos dikhane ke liye storage permission chahiye.",
                color = Color.Gray,
                modifier = Modifier.padding(vertical = 16.dp),
            )
            Button(
                onClick = { launcher.launch(perms) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            ) { Text("Allow access") }
        }
    }
}

@Composable
fun AppNav(vm: GalleryViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<Overlay>() }
    BackHandler(enabled = stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }

    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    val media = vm.media

    Box(Modifier.fillMaxSize()) {
        when (tab) {
            0 -> PhotosScreen(
                media = media,
                onOpen = { list, i -> stack.add(Overlay.Viewer(list, i)) },
                onSettings = { stack.add(Overlay.Settings) },
            )
            1 -> AlbumsScreen(
                media = media,
                onOpen = { title, list -> stack.add(Overlay.Collection(title, list)) },
            )
            else -> ExploreScreen(
                media = media,
                favorites = vm.favorites,
                onOpenViewer = { list, i -> stack.add(Overlay.Viewer(list, i)) },
                onOpenCollection = { title, list -> stack.add(Overlay.Collection(title, list)) },
            )
        }

        if (stack.isEmpty()) {
            NavPill(
                selected = tab,
                onSelect = { tab = it },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp),
            )
        }

        stack.forEachIndexed { i, overlay ->
            key(i) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) {}
                ) {
                    when (overlay) {
                        is Overlay.Viewer -> ViewerScreen(
                            vm = vm,
                            list = overlay.list,
                            start = overlay.index,
                            onEdit = { stack.add(Overlay.Editor(it)) },
                            onClose = { pop() },
                        )
                        is Overlay.Editor -> EditorScreen(
                            vm = vm,
                            media = overlay.media,
                            onClose = { pop() },
                            onSaved = { vm.refresh(); pop() },
                        )
                        is Overlay.Collection -> Box(Modifier.fillMaxSize()) {
                            MediaGrid(
                                media = overlay.list,
                                onOpen = { idx -> stack.add(Overlay.Viewer(overlay.list, idx)) },
                                modifier = Modifier.fillMaxSize(),
                                bottomPad = 24.dp,
                                header = { ScreenTitle(overlay.title) },
                            )
                        }
                        Overlay.Settings -> SettingsScreen(vm = vm, onClose = { pop() })
                    }
                }
            }
        }
    }
}
