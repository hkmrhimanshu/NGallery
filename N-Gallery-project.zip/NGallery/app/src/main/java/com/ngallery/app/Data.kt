package com.ngallery.app

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Media(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val dateMs: Long,
    val bucket: String,
    val name: String,
    val durationMs: Long,
)

object MediaRepository {
    suspend fun load(context: Context): List<Media> = withContext(Dispatchers.IO) {
        val out = ArrayList<Media>()
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DURATION,
        )
        val selection =
            "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
        )
        context.contentResolver.query(
            collection, projection, selection, args,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val iType = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val iTaken = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iBucket = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iDur = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val video = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val taken = c.getLong(iTaken)
                val added = c.getLong(iAdded) * 1000
                val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                out += Media(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    isVideo = video,
                    dateMs = if (taken > 0) taken else added,
                    bucket = c.getString(iBucket) ?: "Other",
                    name = c.getString(iName) ?: "",
                    durationMs = c.getLong(iDur),
                )
            }
        }
        out.sortByDescending { it.dateMs }
        out
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ngallery", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v).apply()

    var model: String
        get() = (sp.getString("model", "") ?: "").ifBlank { NanoBanana.DEFAULT_MODEL }
        set(v) = sp.edit().putString("model", v).apply()

    fun favorites(): Set<String> = (sp.getStringSet("fav", emptySet()) ?: emptySet()).toSet()
    fun setFavorites(s: Set<String>) = sp.edit().putStringSet("fav", s).apply()
}

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    var media by mutableStateOf<List<Media>>(emptyList())
        private set
    var favorites by mutableStateOf(prefs.favorites())
        private set

    fun refresh() {
        viewModelScope.launch { media = MediaRepository.load(getApplication()) }
    }

    fun toggleFav(m: Media) {
        val k = m.uri.toString()
        favorites = if (k in favorites) favorites - k else favorites + k
        prefs.setFavorites(favorites)
    }
}

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

fun formatDay(ms: Long): String {
    val d = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    val pattern = if (d.year == LocalDate.now().year) "d MMMM" else "d MMMM yyyy"
    return d.format(DateTimeFormatter.ofPattern(pattern, Locale.getDefault()))
}

fun formatDateTime(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("d MMMM HH:mm", Locale.getDefault()))

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
