package com.ngallery.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

// Serif title font and mono counters. Swap these for bundled open-source fonts
// (e.g. Instrument Serif, Doto / JetBrains Mono) by adding .ttf files to res/font.
val Serif: FontFamily = FontFamily.Serif
val Mono: FontFamily = FontFamily.Monospace

@Composable
fun NTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color.White,
            onPrimary = Color.Black,
            background = Color.Black,
            surface = Color(0xFF111111),
            onSurface = Color.White,
        )
    ) {
        Surface(
            color = Color.Black,
            contentColor = Color.White,
            modifier = Modifier.fillMaxSize(),
            content = content,
        )
    }
}

/** Frosted dark-glass look: translucent gradient + hairline rim. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(50)): Modifier = this
    .clip(shape)
    .background(Brush.verticalGradient(listOf(Color(0xB0585858), Color(0xB0303030))))
    .border(0.6.dp, Color(0x40FFFFFF), shape)

@Composable
fun GlassPill(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier.glass().padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

/** Click with a springy press-down animation. */
@Composable
fun Modifier.bounceClick(
    enabled: Boolean = true,
    pressedScale: Float = 0.88f,
    onClick: () -> Unit,
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pressed) pressedScale else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "bounce",
    )
    return this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

@Composable
fun BounceIcon(icon: ImageVector, tint: Color = Color.White, size: Dp = 48.dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).bounceClick(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint)
    }
}

/** Checkerboard, shown behind images so transparent areas are visible. */
fun Modifier.checker(cell: Float = 28f): Modifier = this.drawBehind {
    drawRect(Color(0xFF242424))
    val c2 = Color(0xFF383838)
    var y = 0f
    var row = 0
    while (y < size.height) {
        var x = if (row % 2 == 0) 0f else cell
        while (x < size.width) {
            drawRect(c2, topLeft = Offset(x, y), size = Size(cell, cell))
            x += cell * 2f
        }
        y += cell
        row++
    }
}

@Composable
fun PillButton(icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) Color(0xFF262626) else Color(0x00262626),
        tween(260),
        label = "pillBg",
    )
    val iconScale by animateFloatAsState(
        if (selected) 1.14f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "pillIcon",
    )
    Box(
        Modifier
            .size(56.dp)
            .bounceClick(onClick = onClick)
            .clip(CircleShape)
            .background(bg),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(26.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale },
        )
    }
}

@Composable
fun NavPill(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    GlassPill(modifier) {
        PillButton(Icons.Outlined.Image, selected == 0) { onSelect(0) }
        PillButton(Icons.Outlined.PhotoLibrary, selected == 1) { onSelect(1) }
        PillButton(Icons.Outlined.Search, selected == 2) { onSelect(2) }
    }
}
