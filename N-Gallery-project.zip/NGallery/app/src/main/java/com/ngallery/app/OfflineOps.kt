package com.ngallery.app

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentationResult
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** On-device editing tools: no API key, no server. */
object OfflineOps {

    private fun buildPath(pts: List<PointF>, dx: Float, dy: Float, scale: Float): Path {
        val p = Path()
        if (pts.isEmpty()) return p
        p.moveTo(pts[0].x * scale - dx, pts[0].y * scale - dy)
        if (pts.size == 1) {
            p.lineTo(pts[0].x * scale - dx + 0.1f, pts[0].y * scale - dy)
        } else {
            for (i in 1 until pts.size) p.lineTo(pts[i].x * scale - dx, pts[i].y * scale - dy)
        }
        return p
    }

    private fun strokePaint(width: Float, blur: Float): Paint {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = width
        paint.color = Color.WHITE
        if (blur > 0f) paint.maskFilter = BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL)
        return paint
    }

    /** Removes the brushed area and fills it from the surrounding pixels. Works best on small objects. */
    fun erase(base: Bitmap, strokes: List<List<PointF>>, scale: Float, brushDisplayPx: Float): Bitmap {
        val all = strokes.flatten()
        if (all.isEmpty()) return base
        val bw = (brushDisplayPx * scale).coerceAtLeast(4f)

        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (p in all) {
            val x = p.x * scale
            val y = p.y * scale
            if (x < minX) minX = x
            if (y < minY) minY = y
            if (x > maxX) maxX = x
            if (y > maxY) maxY = y
        }
        val margin = bw * 1.2f + 8f
        val left = floor(minX - bw / 2f - margin).toInt().coerceAtLeast(0)
        val top = floor(minY - bw / 2f - margin).toInt().coerceAtLeast(0)
        val right = ceil(maxX + bw / 2f + margin).toInt().coerceAtMost(base.width)
        val bottom = ceil(maxY + bw / 2f + margin).toInt().coerceAtMost(base.height)
        val cw = right - left
        val ch = bottom - top
        if (cw < 2 || ch < 2) return base

        val f = min(1f, 720f / max(cw, ch).toFloat())
        val sw = max(2, (cw * f).toInt())
        val sh = max(2, (ch * f).toInt())

        val crop = Bitmap.createBitmap(base, left, top, cw, ch)
        val small = Bitmap.createScaledBitmap(crop, sw, sh, true)

        // hole mask (small resolution)
        val holeBmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val hc = Canvas(holeBmp)
        val holePaint = strokePaint(bw * f * 1.05f, 0f)
        for (s in strokes) hc.drawPath(buildPath(s, left * f, top * f, scale * f), holePaint)
        val maskPx = IntArray(sw * sh)
        holeBmp.getPixels(maskPx, 0, sw, 0, 0, sw, sh)
        val hole = BooleanArray(sw * sh)
        for (i in maskPx.indices) hole[i] = ((maskPx[i] ushr 24) and 255) > 90

        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        inpaint(px, sw, sh, hole)

        val filled = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        filled.setPixels(px, 0, sw, 0, 0, sw, sh)
        val up = Bitmap.createScaledBitmap(filled, cw, ch, true)

        // feathered blend back into the full-resolution picture
        val layer = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(up, 0f, 0f, null)
        val blend = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val bc = Canvas(blend)
        val blendPaint = strokePaint(bw * 1.5f, (bw * 0.2f).coerceAtLeast(1f))
        for (s in strokes) bc.drawPath(buildPath(s, left.toFloat(), top.toFloat(), scale), blendPaint)
        val dstIn = Paint()
        dstIn.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        lc.drawBitmap(blend, 0f, 0f, dstIn)

        val out = base.copy(Bitmap.Config.ARGB_8888, true) ?: return base
        Canvas(out).drawBitmap(layer, left.toFloat(), top.toFloat(), null)
        return out
    }

    private fun inpaint(px: IntArray, w: Int, h: Int, hole: BooleanArray) {
        val total = w * h
        val known = BooleanArray(total)
        for (i in 0 until total) known[i] = !hole[i]
        val list = IntArray(total)
        var n = 0
        for (i in 0 until total) if (hole[i]) { list[n] = i; n++ }
        if (n == 0) return
        val holeIdx = list.copyOf(n)
        val tmp = IntArray(n)
        val ok = BooleanArray(n)

        // 1) peel the hole from the outside in, averaging known neighbours
        while (n > 0) {
            var progress = 0
            for (k in 0 until n) {
                val i = list[k]
                val x = i % w
                val y = i / w
                var r = 0
                var g = 0
                var b = 0
                var c = 0
                for (dy in -1..1) {
                    val yy = y + dy
                    if (yy < 0 || yy >= h) continue
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val xx = x + dx
                        if (xx < 0 || xx >= w) continue
                        val j = yy * w + xx
                        if (known[j]) {
                            val p = px[j]
                            r += (p shr 16) and 255
                            g += (p shr 8) and 255
                            b += p and 255
                            c++
                        }
                    }
                }
                if (c > 0) {
                    tmp[k] = (255 shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
                    ok[k] = true
                    progress++
                } else {
                    ok[k] = false
                }
            }
            if (progress == 0) break
            var m = 0
            for (k in 0 until n) {
                val i = list[k]
                if (ok[k]) {
                    px[i] = tmp[k]
                    known[i] = true
                } else {
                    list[m] = i
                    m++
                }
            }
            n = m
        }

        // 2) smooth only inside the hole so it blends in
        repeat(28) {
            for (i in holeIdx) {
                val x = i % w
                val y = i / w
                var r = 0
                var g = 0
                var b = 0
                var c = 0
                for (dy in -1..1) {
                    val yy = y + dy
                    if (yy < 0 || yy >= h) continue
                    for (dx in -1..1) {
                        val xx = x + dx
                        if (xx < 0 || xx >= w) continue
                        val p = px[yy * w + xx]
                        r += (p shr 16) and 255
                        g += (p shr 8) and 255
                        b += p and 255
                        c++
                    }
                }
                px[i] = (255 shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
            }
        }
    }

    private fun scaleDown(b: Bitmap, maxSide: Int): Bitmap {
        val s = max(b.width, b.height)
        if (s <= maxSide) return b
        val f = maxSide.toFloat() / s
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    /** Detects the main subject on-device (ML Kit) and puts a plain colour behind it. */
    suspend fun changeBackground(src: Bitmap, bgColor: Int): Result<Bitmap> = runCatching {
        val small = withContext(Dispatchers.Default) { scaleDown(src, 1280) }
        val segmenter = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        )
        try {
            val res = suspendCancellableCoroutine<SubjectSegmentationResult> { cont ->
                segmenter.process(InputImage.fromBitmap(small, 0))
                    .addOnSuccessListener { cont.resume(it) }
                    .addOnFailureListener { cont.resumeWithException(it) }
            }
            val fg = res.foregroundBitmap ?: error("Photo me koi subject nahi mila")
            withContext(Dispatchers.Default) {
                val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(out)
                canvas.drawColor(bgColor)
                canvas.drawBitmap(fg, null, Rect(0, 0, src.width, src.height), Paint(Paint.FILTER_BITMAP_FLAG))
                out
            }
        } finally {
            segmenter.close()
        }
    }
}
