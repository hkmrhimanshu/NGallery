package com.sangvya.app

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.location.*
import android.os.*
import android.view.*
import android.widget.*
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import com.google.android.gms.tasks.Task
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONObject
import java.util.UUID
import kotlin.math.*

class MainActivity : Activity() {
    private val serviceId = "com.sangvya.app.NEARBY"
    private val strategy = Strategy.P2P_CLUSTER
    private val endpointNames = linkedMapOf<String, String>()
    private val blocked = mutableSetOf<String>()
    private val locations = mutableMapOf<String, Location>()
    private val chatHistory = mutableListOf<String>()
    private var displayName = "My Name"
    private var groupToken = UUID.randomUUID().toString().take(8).uppercase()
    private var alertMeters = 10
    private var ringOn = true
    private var vibrateOn = true
    private var lastAlert = mutableSetOf<String>()
    private var groupChat = true
    private var privateTarget: String? = null
    private var locationManager: LocationManager? = null
    private var myLocation: Location? = null
    private var advertising = false
    private var discovering = false
    private lateinit var body: LinearLayout
    private lateinit var title: TextView
    private val peers get() = endpointNames.toMap()

    private val scanner = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            val token = result.contents
            if (token.startsWith("SANGVYA:")) {
                groupToken = token.removePrefix("SANGVYA:")
                startNearby()
                toast("Invite scanned. Nearby discovery started; accept the friend's request.")
            } else toast("This QR is not a Sangvya invite")
        }
    }

    private val connectionLifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            if (blocked.contains(info.endpointName)) {
                Nearby.getConnectionsClient(this@MainActivity).rejectConnection(id); return
            }
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity).setTitle("Connect request")
                    .setMessage("${info.endpointName} wants to connect.")
                    .setPositiveButton("Accept") { _, _ -> Nearby.getConnectionsClient(this@MainActivity).acceptConnection(id, payloadCallback) }
                    .setNegativeButton("Ignore") { _, _ -> Nearby.getConnectionsClient(this@MainActivity).rejectConnection(id) }
                    .setCancelable(false).show()
            }
        }
        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            runOnUiThread {
                if (result.status.isSuccess) {
                    endpointNames[id] = endpointNames[id] ?: "Friend ${id.takeLast(4)}"
                    refreshHome()
                    toast("Connected: ${endpointNames[id]}")
                    sendPayload(id, "HELLO|$displayName")
                    sendMyLocation(id)
                } else toast("Connection was not completed")
            }
        }
        override fun onDisconnected(id: String) {
            runOnUiThread { endpointNames.remove(id); locations.remove(id); refreshHome(); toast("A friend disconnected") }
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val msg = String(bytes)
            runOnUiThread {
                when {
                    msg.startsWith("HELLO|") -> { endpointNames[id] = msg.substringAfter("|"); refreshHome() }
                    msg.startsWith("LOC|") -> {
                        val p = msg.split("|")
                        if (p.size >= 4) {
                            val loc = Location("peer").apply { latitude=p[1].toDouble(); longitude=p[2].toDouble(); time=System.currentTimeMillis() }
                            locations[id] = loc
                            refreshHome()
                            checkDistanceAlert(id, loc)
                        }
                    }
                    msg.startsWith("CHAT|") -> {
                        chatHistory.add("${endpointNames[id] ?: "Friend"}: ${msg.substringAfter("|")}")
                        if (body.tag == "chat") showChats()
                    }
                }
            }
        }
        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }

    private val endpointDiscovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            runOnUiThread {
                if (!blocked.contains(info.endpointName)) {
                    AlertDialog.Builder(this@MainActivity).setTitle("Nearby friend")
                        .setMessage("${info.endpointName} is nearby. Send a connection request?")
                        .setPositiveButton("Connect") { _, _ ->
                            Nearby.getConnectionsClient(this@MainActivity).requestConnection(displayName, id, connectionLifecycle)
                                .addOnFailureListener { toast("Request failed: ${it.localizedMessage}") }
                        }.setNegativeButton("Ignore", null).show()
                }
            }
        }
        override fun onEndpointLost(id: String) { }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("sangvya", MODE_PRIVATE)
        displayName = prefs.getString("name", "My Name") ?: "My Name"
        ringOn = prefs.getBoolean("ring", true); vibrateOn = prefs.getBoolean("vibrate", true)
        alertMeters = prefs.getInt("distance", 10)
        setContentView(buildRoot())
        requestPermissionsIfNeeded()
        startGps()
        showHome()
    }

    private fun buildRoot(): View {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); setPadding(dp(16),dp(12),dp(16),dp(12)) }
        title = TextView(this).apply { text="Sangvya  ◉"; textSize=28f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD; setPadding(0,dp(6),0,dp(18)) }
        root.addView(title)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    private fun showHome() {
        body.tag = "home"; body.removeAllViews()
        val grid = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val row1 = LinearLayout(this); val row2 = LinearLayout(this)
        row1.addView(tile("▣","CONNECT") { showConnect() }, LinearLayout.LayoutParams(0,dp(148),1f).apply { rightMargin=dp(8); bottomMargin=dp(8) })
        row1.addView(tile("⌖","LIVE LOCATION") { showLocations() }, LinearLayout.LayoutParams(0,dp(148),1f).apply { leftMargin=dp(8); bottomMargin=dp(8) })
        row2.addView(tile("●","CHATS") { showChats() }, LinearLayout.LayoutParams(0,dp(148),1f).apply { rightMargin=dp(8) })
        row2.addView(tile("⚙","SETTINGS") { showSettings() }, LinearLayout.LayoutParams(0,dp(148),1f).apply { leftMargin=dp(8) })
        grid.addView(row1); grid.addView(row2); body.addView(grid)
        addSection("CONNECTED FRIENDS")
        if (endpointNames.isEmpty()) addText("No connected friends yet. Open Connect on both phones.", 15, GRAY)
        endpointNames.values.forEachIndexed { i,n -> addText("${i+1}. $n  •  Connected",18,WHITE,true) }
        addSection("NEARBY FRIENDS")
        if (endpointNames.isEmpty()) addText("Nearby friends appear after you tap Start Nearby.",14,GRAY)
        addButton("START NEARBY DISCOVERY") { startNearby() }
    }

    private fun tile(symbol:String, label:String, action:()->Unit): View {
        return LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setBackgroundColor(Color.WHITE); setPadding(dp(8),dp(12),dp(8),dp(12))
            addView(TextView(this@MainActivity).apply { text=symbol; textSize=42f; setTextColor(Color.BLACK); gravity=Gravity.CENTER })
            addView(TextView(this@MainActivity).apply { text=label; textSize=13f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.BLACK); gravity=Gravity.CENTER })
            setOnClickListener { action() }
            background = rounded(Color.WHITE, 28)
        }
    }

    private fun showConnect() {
        body.tag="connect"; body.removeAllViews(); addHeader("CONNECT WITH FRIENDS")
        addText("Connect with up to 8 nearby friends. Both phones must have Sangvya open and approve the request.",14,GRAY)
        addButton("CREATE / SHOW MY QR CODE") { showQr() }
        addButton("SCAN FRIEND'S QR CODE") {
            val opt=ScanOptions().setPrompt("Scan your friend's Sangvya QR").setBeepEnabled(false).setOrientationLocked(true)
            scanner.launch(opt)
        }
        addButton(if (discovering) "STOP NEARBY DISCOVERY" else "START NEARBY DISCOVERY") { if(discovering) stopNearby() else startNearby(); showConnect() }
        addButton("BACK HOME") { showHome() }
    }

    private fun showQr() {
        body.tag="qr"; body.removeAllViews(); addHeader("YOUR SANGVYA INVITE")
        addText("Ask your friend to scan this QR. They still need to send a request and you must accept.",14,GRAY)
        try {
            val matrix=MultiFormatWriter().encode("SANGVYA:$groupToken",BarcodeFormat.QR_CODE,650,650)
            val bmp=Bitmap.createBitmap(650,650,Bitmap.Config.RGB_565)
            for(x in 0 until 650) for(y in 0 until 650) bmp.setPixel(x,y,if(matrix[x,y]) Color.BLACK else Color.WHITE)
            body.addView(ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds=true; setPadding(dp(18),dp(18),dp(18),dp(18)); background=rounded(Color.WHITE,20) },
                LinearLayout.LayoutParams(-1,dp(300)).apply { topMargin=dp(18); bottomMargin=dp(18) })
        } catch (_:Exception) { addText("Could not create QR",14,WHITE) }
        addText("Invite code: $groupToken",14,WHITE,true)
        addButton("BACK") { showConnect() }
    }

    private fun showLocations() {
        body.tag="locations"; body.removeAllViews(); addHeader("LIVE LOCATION")
        val mine=myLocation
        addText(if(mine==null) "Waiting for GPS fix…" else "You: ${fmt(mine.latitude)}, ${fmt(mine.longitude)}",14,GRAY)
        if(endpointNames.isEmpty()) addText("No connected friends are sharing location yet.",14,GRAY)
        endpointNames.forEach { (id,name) ->
            val loc=locations[id]
            if(loc==null) addText("$name • Waiting for location…",17,WHITE,true)
            else {
                val distance=mine?.distanceTo(loc)?.toInt()
                val direction=mine?.let { directionText(it,loc) } ?: "Direction unavailable"
                addText("$name\n${distance?.let{"$it m away"} ?: "Distance unavailable"} • $direction\n${fmt(loc.latitude)}, ${fmt(loc.longitude)}",17,WHITE,true)
            }
        }
        addText("Location is shared only with connected friends while this app is open.",12,GRAY)
        addButton("BACK HOME") { showHome() }
    }

    private fun showChats() {
        body.tag="chat"; body.removeAllViews(); addHeader("CHATS")
        val modes=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        modes.addView(button("GROUP CHAT") { groupChat=true; privateTarget=null; showChats() },LinearLayout.LayoutParams(0,dp(48),1f))
        modes.addView(button("PRIVATE CHAT") { choosePrivate() },LinearLayout.LayoutParams(0,dp(48),1f))
        body.addView(modes)
        addText(if(groupChat) "Group conversation" else "Private: ${privateTarget ?: "Choose a friend"}",14,RED,true)
        chatHistory.forEach { addText(it,15,WHITE) }
        val input=EditText(this).apply { hint="Write a message"; setTextColor(WHITE); setHintTextColor(GRAY); setBackground(rounded(0xFF191919.toInt(),14)) }
        body.addView(input)
        addButton("SEND MESSAGE") {
            val msg=input.text.toString().trim()
            if(msg.isNotEmpty()) {
                chatHistory.add("Me: $msg")
                val targets=if(groupChat) endpointNames.keys.toList() else endpointNames.filterValues { it==privateTarget }.keys.toList()
                targets.forEach { sendPayload(it,"CHAT|$msg") }
                showChats()
            }
        }
        addButton("BACK HOME") { showHome() }
    }

    private fun choosePrivate() {
        if(endpointNames.isEmpty()) { toast("Connect a friend first"); return }
        val names=endpointNames.values.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose friend").setItems(names) { _, which ->
            privateTarget=names[which]; groupChat=false; showChats()
        }.show()
    }

    private fun showSettings() {
        body.tag="settings"; body.removeAllViews(); addHeader("SETTINGS")
        val name=EditText(this).apply { setText(displayName); hint="Your name"; setTextColor(WHITE); setHintTextColor(GRAY); setBackground(rounded(0xFF191919.toInt(),14)) }
        body.addView(name)
        addButton("SAVE NAME") { displayName=name.text.toString().trim().ifEmpty{"Friend"}; getSharedPreferences("sangvya",0).edit().putString("name",displayName).apply(); toast("Name saved") }
        body.addView(checkRow("Ring alert",ringOn) { ringOn=it; savePrefs() })
        body.addView(checkRow("Vibration alert",vibrateOn) { vibrateOn=it; savePrefs() })
        addText("Alert distance: $alertMeters metres",16,WHITE,true)
        val seek=SeekBar(this).apply { max=199; progress=alertMeters-1 }
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean) { alertMeters=p+1; savePrefs() }
            override fun onStartTrackingTouch(s:SeekBar?) {}
            override fun onStopTrackingTouch(s:SeekBar?) {}
        })
        body.addView(seek)
        addButton("MANAGE BLOCKED FRIENDS") {
            val arr=blocked.toTypedArray()
            if(arr.isEmpty()) toast("No blocked friends")
            else AlertDialog.Builder(this).setTitle("Blocked friends").setItems(arr) { _,i -> blocked.remove(arr[i]); toast("Unblocked") }.show()
        }
        addButton("BACK HOME") { showHome() }
    }

    private fun checkRow(label:String, checked:Boolean, changed:(Boolean)->Unit): View =
        CheckBox(this).apply { text=label; setTextColor(WHITE); isChecked=checked; buttonTintList=android.content.res.ColorStateList.valueOf(RED); setOnCheckedChangeListener { _,v -> changed(v) } }

    private fun startNearby() {
        if(endpointNames.size>=8) { toast("Group is full (8 friends max)"); return }
        if(!hasNearbyPermissions()) { requestPermissionsIfNeeded(); toast("Allow Nearby/Bluetooth permissions, then try again"); return }
        val client=Nearby.getConnectionsClient(this)
        advertising=true; discovering=true
        client.startAdvertising(displayName,serviceId,connectionLifecycle,
            AdvertisingOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { advertising=false; toast("Advertising failed: ${it.localizedMessage}") }
        client.startDiscovery(serviceId,endpointDiscovery,DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { discovering=false; toast("Discovery failed: ${it.localizedMessage}") }
        toast("Nearby mode started. Keep this screen open.")
    }

    private fun stopNearby() {
        Nearby.getConnectionsClient(this).stopAdvertising()
        Nearby.getConnectionsClient(this).stopDiscovery()
        advertising=false; discovering=false; toast("Nearby discovery stopped")
    }

    private fun sendPayload(id:String, text:String) {
        Nearby.getConnectionsClient(this).sendPayload(id,Payload.fromBytes(text.toByteArray()))
    }

    private fun startGps() {
        locationManager=getSystemService(LOCATION_SERVICE) as LocationManager
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return
        try {
            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER,4000L,2f,object:LocationListener {
                override fun onLocationChanged(location:Location) { myLocation=location; endpointNames.keys.forEach{sendMyLocation(it)}; if(body.tag=="locations") showLocations() }
            },Looper.getMainLooper())
        } catch (_:SecurityException) {}
    }

    private fun sendMyLocation(id:String) {
        val l=myLocation ?: return
        sendPayload(id,"LOC|${l.latitude}|${l.longitude}|${System.currentTimeMillis()}")
    }

    private fun checkDistanceAlert(id:String, loc:Location) {
        val mine=myLocation ?: return
        val distance=mine.distanceTo(loc)
        if(distance>alertMeters && !lastAlert.contains(id)) {
            lastAlert.add(id)
            if(vibrateOn) {
                val v=getSystemService(VIBRATOR_SERVICE) as Vibrator
                if(Build.VERSION.SDK_INT>=26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0,400,150,400),-1))
            }
            if(ringOn) try {
                val uri=android.provider.Settings.System.DEFAULT_RINGTONE_URI
                val ringtone=android.media.RingtoneManager.getRingtone(this,uri); ringtone.play()
                Handler(Looper.getMainLooper()).postDelayed({ try{ringtone.stop()}catch(_:Exception){} },2500)
            } catch (_:Exception) {}
            toast("${endpointNames[id] ?: "Friend"} is about ${distance.toInt()} m away")
        } else if(distance<=alertMeters) lastAlert.remove(id)
    }

    private fun directionText(from:Location,to:Location):String {
        val bearing=from.bearingTo(to)
        val delta=((bearing+360)%360)
        val dir=when { delta<45 || delta>=315 -> "ahead"; delta<135 -> "right"; delta<225 -> "behind"; else -> "left" }
        return dir
    }

    private fun hasNearbyPermissions():Boolean {
        val needed=if(Build.VERSION.SDK_INT>=31) listOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_ADVERTISE,Manifest.permission.BLUETOOTH_CONNECT)
            else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return needed.all { checkSelfPermission(it)==PackageManager.PERMISSION_GRANTED } &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissionsIfNeeded() {
        val p=mutableListOf<String>()
        val candidates=if(Build.VERSION.SDK_INT>=31) listOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_ADVERTISE,Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.ACCESS_FINE_LOCATION)
            else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        candidates.forEach { if(checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED) p.add(it) }
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        if(p.isNotEmpty()) requestPermissions(p.distinct().toTypedArray(),100)
    }

    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) {
        super.onRequestPermissionsResult(r,p,g)
        if(r==100) { startGps(); toast("Permissions updated. Tap Start Nearby again.") }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { Nearby.getConnectionsClient(this).stopAllEndpoints(); stopNearby() } catch (_:Exception) {}
    }

    private fun refreshHome() { if(body.tag=="home") showHome() else if(body.tag=="locations") showLocations() }
    private fun savePrefs() { getSharedPreferences("sangvya",0).edit().putBoolean("ring",ringOn).putBoolean("vibrate",vibrateOn).putInt("distance",alertMeters).apply() }
    private fun addHeader(s:String) { addText(s,21,WHITE,true) }
    private fun addSection(s:String) { addText(s,17,WHITE,true) }
    private fun addText(s:String,size:Int,color:Int,bold:Boolean=false) {
        body.addView(TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(0,dp(9),0,dp(9)) })
    }
    private fun addButton(s:String, action:()->Unit) { body.addView(button(s,action),LinearLayout.LayoutParams(-1,dp(50)).apply { topMargin=dp(7); bottomMargin=dp(7) }) }
    private fun button(s:String, action:()->Unit):Button = Button(this).apply {
        text=s; textSize=13f; setTextColor(Color.BLACK); setBackground(rounded(0xFFFF1744.toInt(),14)); setOnClickListener { action() }
    }
    private fun rounded(color:Int,r:Float):android.graphics.drawable.Drawable = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius=dp(r.toInt()).toFloat() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun fmt(v:Double)="%.5f".format(v)
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    companion object { val WHITE=Color.WHITE; val GRAY=0xFF9AA0AA.toInt(); val RED=0xFFFF1744.toInt() }
}
