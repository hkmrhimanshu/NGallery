package com.ngallery.app

import android.app.Activity
import android.content.Intent
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun ViewerScreen(
    vm: GalleryViewModel,
    list: List<Media>,
    start: Int,
    onEdit: (Media) -> Unit,
    onClose: () -> Unit,
) {
    if (list.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(initialPage = start.coerceIn(0, list.lastIndex)) { list.size }
    val cur = list[pager.currentPage.coerceIn(0, list.lastIndex)]
    val isFav = cur.uri.toString() in vm.favorites
    val strip = rememberLazyListState()
    var menu by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }

    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            vm.refresh()
            onClose()
        }
    }

    LaunchedEffect(pager.currentPage) {
        strip.animateScrollToItem((pager.currentPage - 3).coerceAtLeast(0))
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        // top bar
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().height(72.dp).padding(start = 22.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(formatDateTime(cur.dateMs), color = Color.White, fontSize = 19.sp, modifier = Modifier.weight(1f))
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Outlined.MoreVert, null, tint = Color.White)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Details") }, onClick = { menu = false; info = true })
                }
            }
        }

        // media pager
        HorizontalPager(
            state = pager,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            beyondViewportPageCount = 0,
        ) { p ->
            val m = list[p]
            if (m.isVideo) {
                VideoPage(m, active = pager.currentPage == p)
            } else {
                AsyncImage(
                    model = m.uri,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }

        // filmstrip
        LazyRow(
            state = strip,
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            modifier = Modifier.fillMaxWidth().height(62.dp).padding(vertical = 1.dp),
        ) {
            itemsIndexed(list, key = { _, m -> m.uri.toString() }) { i, m ->
                val sel = i == pager.currentPage
                AsyncImage(
                    model = remember(m.uri) { thumbReq(ctx, m.uri, 160) },
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(if (sel) 64.dp else 40.dp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(4.dp))
                        .then(if (sel) Modifier.border(1.dp, Color.White, RoundedCornerShape(4.dp)) else Modifier)
                        .clickable { scope.launch { pager.scrollToPage(i) } },
                )
            }
        }

        // actions
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().height(72.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { vm.toggleFav(cur) }) {
                Icon(
                    if (isFav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    null,
                    tint = if (isFav) Color(0xFFFF5A5F) else Color.White,
                )
            }
            IconButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = if (cur.isVideo) "video/*" else "image/*"
                    putExtra(Intent.EXTRA_STREAM, cur.uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, null))
            }) { Icon(Icons.Outlined.Share, null, tint = Color.White) }
            IconButton(onClick = {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, listOf(cur.uri))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            }) { Icon(Icons.Outlined.Delete, null, tint = Color.White) }
            IconButton(onClick = {
                if (cur.isVideo) toast(ctx, "Video editing abhi nahi hai") else onEdit(cur)
            }) { Icon(Icons.Outlined.Edit, null, tint = Color.White) }
        }
    }

    if (info) {
        AlertDialog(
            onDismissRequest = { info = false },
            confirmButton = { TextButton(onClick = { info = false }) { Text("OK") } },
            title = { Text("Details") },
            text = {
                Text("${cur.name}\nAlbum: ${cur.bucket}\n${formatDateTime(cur.dateMs)}")
            },
        )
    }
}

@Composable
private fun VideoPage(m: Media, active: Boolean) {
    val ctx = LocalContext.current
    if (!active) {
        AsyncImage(
            model = remember(m.uri) { thumbReq(ctx, m.uri, 720) },
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
    } else {
        val player = remember(m.uri) {
            ExoPlayer.Builder(ctx).build().apply {
                setMediaItem(MediaItem.fromUri(m.uri))
                prepare()
                playWhenReady = true
            }
        }
        DisposableEffect(player) { onDispose { player.release() } }
        AndroidView(
            factory = { c -> PlayerView(c).apply { this.player = player; useController = true } },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize(),
        )
    }
}
