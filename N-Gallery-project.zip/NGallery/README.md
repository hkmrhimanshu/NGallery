# N Gallery

Nothing-style gallery app (Kotlin + Jetpack Compose) with AI editing via Nano Banana (Gemini image model).

## APK kaise banaye (phone se, bina Android Studio)

1. github.com par free account banao, naya repository banao (e.g. `NGallery`).
2. Is zip ke andar ki saari files repository me upload karo (Add file -> Upload files).
   `.github` folder bhi upload hona chahiye (workflow isi me hai).
3. Repository ke **Actions** tab me "Build APK" run hoga (ya "Run workflow" dabao).
4. 5-10 minute baad run khatam hoga. Run par click karo, neeche **Artifacts** me `N-Gallery-APK` download karo.
5. Zip kholo, `app-debug.apk` install karo ("Install unknown apps" allow karna padega).

## Android Studio se
Folder open karo -> Build -> Build APK(s). Min Android 11 (API 30).

## AI features chalane ke liye
App me Photos -> menu (⋮) -> Settings -> Gemini API key daalo
(free key: https://aistudio.google.com/apikey). Model name Settings me badal sakte ho.

- AI Eraser: object par brush chalao -> Erase
- Replace: brush + "Replace with..." -> Replace
- Background: white ya apna prompt
- AI Edit: koi bhi instruction

## Fonts / icons
Title font abhi system serif hai. Instrument Serif / Doto jaise open-source fonts `res/font` me daal kar
`Theme.kt` ke `Serif` / `Mono` me lagao.
