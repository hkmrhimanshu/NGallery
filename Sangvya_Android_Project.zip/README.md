# Sangvya

Dark Android friends-connect prototype for 2–8 people.

Included: dark home UI; QR invitation display and scanner; Nearby Connections discovery, accept/reject; connected peer list; group/private chat UI over active nearby connections; local GPS sharing to connected peers; approximate distance/direction; distance threshold alerts; local ring/vibration preferences; local block list.

Technical notes:
- Nearby Connections uses Google Play services and negotiates Bluetooth/BLE/Wi-Fi transports. Mobile data is not required for nearby connections, but supported Google Play services are required.
- QR invite is a short app invitation token; scanning starts nearby discovery/connection flow. Both users must accept.
- Location is shared only with connected peers while the app is open and location permission is granted. No remote internet relay is implemented.
- Background reliability, end-to-end encryption, remote online tracking, online maps, server accounts and group-wide moderation are future work.
- Distance and compass direction are approximate and depend on GPS/sensor quality.
- Blocking in this prototype is local to this phone.
- Use only with the consent of all participants.

Upload project contents to repository root. GitHub Actions → Build Sangvya APK → download Sangvya-debug-apk from Artifacts.
