package com.friendsconnect.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.*
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.content.Intent
import android.provider.Settings
import java.util.UUID
import kotlin.math.pow

class MainActivity : Activity() {
    private val serviceUuid = ParcelUuid(UUID.fromString("7b7e1000-7a31-4d5c-9f31-8a7b2c010001"))
    private val peers = linkedMapOf<String, Peer>()
    private lateinit var status: TextView
    private lateinit var peerList: LinearLayout
    private lateinit var threshold: SeekBar
    private lateinit var thresholdLabel: TextView
    private lateinit var locationText: TextView
    private var alertMeters = 10
    private var alerted = mutableSetOf<String>()
    private var scanner: BluetoothLeScanner? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanCallback: ScanCallback? = null
    private var locationManager: LocationManager? = null
    private var lastLocation: Location? = null
    private val handler = Handler(Looper.getMainLooper())

    data class Peer(val name: String, var rssi: Int, var distance: Double, var lastSeen: Long)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9,13,18)
        window.navigationBarColor = Color.rgb(9,13,18)
        buildUi()
        requestNeededPermissions()
        startLocation()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 20)
            setBackgroundColor(Color.rgb(9,13,18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = text("SANGVYA", 22, Color.WHITE, true)
        content.addView(title)
        content.addView(text("Stay together • Offline-first", 14, 0xFF9AA7B5.toInt(), false))
        content.addView(space(22))
        val card = panel()
        status = text("Not connected yet", 16, 0xFFA7F3D0.toInt(), true)
        card.addView(status)
        card.addView(text("Nearby Android phones running Friends Connect will appear here.", 13, 0xFF9AA7B5.toInt(), false))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = button("START NEARBY")
        start.setOnClickListener { startNearby() }
        val stop = button("STOP")
        stop.setOnClickListener { stopNearby() }
        buttons.addView(start, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        card.addView(buttons)
        content.addView(card)
        content.addView(space(18))
        content.addView(text("ALERT DISTANCE", 13, 0xFF9AA7B5.toInt(), true))
        thresholdLabel = text("Alert when a friend is farther than 10 m", 16, Color.WHITE, true)
        content.addView(thresholdLabel)
        threshold = SeekBar(this).apply { max = 199; progress = 9 }
        threshold.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                alertMeters = p + 1
                thresholdLabel.text = "Alert when a friend is farther than $alertMeters m"
                checkAlerts()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        content.addView(threshold)
        content.addView(space(18))
        content.addView(text("FRIENDS NEARBY", 13, 0xFF9AA7B5.toInt(), true))
        peerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(peerList)
        content.addView(space(18))
        content.addView(text("MY LOCATION", 13, 0xFF9AA7B5.toInt(), true))
        locationText = text("Waiting for GPS permission…", 14, Color.WHITE, false)
        content.addView(locationText)
        content.addView(space(18))
        content.addView(text("MESSAGES", 13, 0xFF9AA7B5.toInt(), true))
        val msg = EditText(this).apply {
            hint = "Offline message feature: coming in next version"
            setHintTextColor(0xFF718096.toInt()); setTextColor(Color.WHITE)
            isEnabled = false
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFF17212B.toInt())
        }
        content.addView(msg)
        content.addView(space(12))
        content.addView(text("MVP note: nearby discovery and RSSI-based distance alerts work over Bluetooth LE. GPS is shown locally. Remote live tracking and cross-device chat need an internet relay or a later Wi‑Fi Direct data channel.", 12, 0xFF81909F.toInt(), false))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun startNearby() {
        if (!hasPermissions()) { requestNeededPermissions(); return }
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            status.text = "Please turn on Bluetooth"
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return
        }
        scanner = adapter.bluetoothLeScanner
        advertiser = adapter.bluetoothLeAdvertiser
        if (scanner == null || advertiser == null) {
            status.text = "BLE advertising/scanning is unavailable on this phone"; return
        }
        try {
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                .setConnectable(false).build()
            val data = AdvertiseData.Builder().addServiceUuid(serviceUuid).setIncludeDeviceName(false).build()
            advertiser?.startAdvertising(settings, data, advertiseCallback)
            val filter = ScanFilter.Builder().setServiceUuid(serviceUuid).build()
            val scanSettings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
            scanCallback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    val addr = result.device.address
                    if (addr == android.bluetooth.BluetoothDevice::class.java.name) return
                    val rssi = result.rssi
                    val distance = estimateDistance(rssi)
                    peers[addr] = Peer("Friend ${addr.takeLast(5)}", rssi, distance, System.currentTimeMillis())
                    renderPeers()
                    checkAlerts()
                }
                override fun onScanFailed(errorCode: Int) { status.text = "Bluetooth scan failed: $errorCode" }
            }
            scanner?.startScan(listOf(filter), scanSettings, scanCallback)
            status.text = "Scanning nearby • Keep Bluetooth on"
        } catch (e: SecurityException) {
            status.text = "Bluetooth permission required"
        } catch (e: Exception) {
            status.text = "Could not start nearby scan: ${e.message}"
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) { runOnUiThread { status.text = "Visible to nearby Friends Connect phones" } }
        override fun onStartFailure(errorCode: Int) { runOnUiThread { status.text = "Bluetooth advertising failed: $errorCode" } }
    }

    private fun stopNearby() {
        try { scanCallback?.let { scanner?.stopScan(it) }; advertiser?.stopAdvertising(advertiseCallback) } catch (_: Exception) {}
        scanCallback = null
        status.text = "Nearby mode stopped"
    }

    private fun estimateDistance(rssi: Int): Double {
        // Rough indoor estimate only; walls, phone models and orientation affect accuracy.
        return 10.0.pow((-59.0 - rssi) / 20.0).coerceIn(0.5, 500.0)
    }

    private fun renderPeers() {
        peerList.removeAllViews()
        val now = System.currentTimeMillis()
        peers.entries.removeAll { now - it.value.lastSeen > 15000 }
        if (peers.isEmpty()) {
            peerList.addView(text("No nearby friends detected yet.", 14, 0xFF9AA7B5.toInt(), false)); return
        }
        peers.values.sortedBy { it.distance }.forEach { p ->
            val row = panel()
            row.addView(text(p.name, 16, Color.WHITE, true))
            row.addView(text("Approx. ${p.distance.toInt()} m away  •  signal ${p.rssi} dBm", 13, 0xFFA7F3D0.toInt(), false))
            peerList.addView(row)
        }
    }

    private fun checkAlerts() {
        peers.forEach { (id, p) ->
            if (p.distance > alertMeters && !alerted.contains(id)) {
                alerted.add(id)
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 350, 180, 350), -1))
                Toast.makeText(this, "${p.name} is beyond ${alertMeters} m (approx.)", Toast.LENGTH_LONG).show()
            } else if (p.distance <= alertMeters) alerted.remove(id)
        }
    }

    private fun startLocation() {
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!hasLocationPermission()) return
        try {
            val provider = if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            locationManager?.requestLocationUpdates(provider, 3000L, 2f, object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    lastLocation = location
                    locationText.text = "Lat ${"%.5f".format(location.latitude)}  •  Lon ${"%.5f".format(location.longitude)}"
                }
            }, Looper.getMainLooper())
            locationManager?.getLastKnownLocation(provider)?.let {
                lastLocation = it
                locationText.text = "Lat ${"%.5f".format(it.latitude)}  •  Lon ${"%.5f".format(it.longitude)}"
            }
        } catch (_: SecurityException) {}
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_SCAN)
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (needed.isNotEmpty()) requestPermissions(needed.distinct().toTypedArray(), 44)
    }
    private fun hasLocationPermission() = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    private fun hasPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= 31) checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
        else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44) {
            startLocation()
            status.text = if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) "Permissions granted — tap START NEARBY" else "Permissions needed for nearby discovery and GPS"
        }
    }

    private fun panel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        setBackgroundColor(0xFF141D27.toInt())
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); layoutParams = lp
    }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(4))
    }
    private fun button(s: String) = Button(this).apply {
        text = s; textSize = 12f; setTextColor(Color.BLACK); setBackgroundColor(0xFFA7F3D0.toInt())
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
