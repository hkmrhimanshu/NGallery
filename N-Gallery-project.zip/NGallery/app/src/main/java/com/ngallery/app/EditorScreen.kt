package com.ngallery.app

import android.graphics.PointF
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Contrast
import androidx.compose.material.icons.outlined.Crop
import androidx.compose.material.icons.outlined.Flip
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Redo
import androidx.compose.material.icons.outlined.RotateLeft
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class EditTab(val icon: ImageVector) {
    Adjust(Icons.Outlined.Tune),
    Rotate(Icons.Outlined.Crop),
    Ai(Icons.Outlined.AutoAwesome),
}

private enum class Adj(val label: String, val icon: ImageVector) {
    Exposure("Exposure", Icons.Outlined.WbSunny),
    Contrast("Contrast", Icons.Outlined.Contrast),
    Saturation("Saturation", Icons.Outlined.Palette),
    Warmth("Warmth", Icons.Outlined.Thermostat),
}

private enum class AiTool(val label: String, val icon: ImageVector) {
    Eraser("Eraser", Icons.Outlined.AutoFixHigh),
    RemoveBg("Remove BG", Icons.Outlined.ContentCut),
    Background("Background", Icons.Outlined.Wallpaper),
}

@Composable
private fun ToolItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val a by animateFloatAsState(if (selected) 1f else 0.6f, tween(220), label = "toolAlpha")
    val sc by animateFloatAsState(
        if (selected) 1.1f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "toolScale",
    )
    Column(
        Modifier
            .bounceClick(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .graphicsLayer { alpha = a; scaleX = sc; scaleY = sc },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun EditorScreen(vm: GalleryViewModel, media: Media, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    var history by remember { mutableStateOf<List<EditState>>(emptyList()) }
    var idx by remember { mutableIntStateOf(0) }
    var draft by remember { mutableStateOf<EditState?>(null) }
    var loading by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    var tab by remember { mutableStateOf(EditTab.Adjust) }
    var adj by remember { mutableStateOf(Adj.Exposure) }
    var ai by remember { mutableStateOf(AiTool.Eraser) }
    var bgColor by remember { mutableStateOf(Color.White) }
    var brushDp by remember { mutableFloatStateOf(36f) }

    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var dispW by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(media.uri) {
        val bmp = withContext(Dispatchers.IO) { decodeBitmap(ctx, media.uri, 3072) }
        if (bmp != null) {
            history = listOf(EditState(bmp))
            idx = 0
        }
        loading = false
    }

    val state = history.getOrNull(idx)
    val shown = draft ?: state
    val canUndo = idx > 0
    val canRedo = idx < history.lastIndex
    val dirty = idx > 0 || draft != null
    val brushMode = tab == EditTab.Ai && ai == AiTool.Eraser && !busy
    val brushPx = with(density) { brushDp.dp.toPx() }

    fun commit(s: EditState) {
        history = history.take(idx + 1) + s
        idx = history.lastIndex
        draft = null
    }

    fun save() {
        val s = shown ?: return
        busy = true
        scope.launch {
            val uri = withContext(Dispatchers.IO) { saveToGallery(ctx, renderFinal(s)) }
            busy = false
            if (uri != null) {
                toast(ctx, "Saved: Pictures/N Gallery")
                onSaved()
            } else toast(ctx, "Save nahi ho paya")
        }
    }

    fun runAi() {
        val base = shown?.bitmap ?: return
        val carry = shown
        if (ai == AiTool.Eraser) {
            if (strokes.isEmpty()) {
                toast(ctx, "Pehle object par brush chalao")
                return
            }
            val snapshot = strokes.map { s -> s.map { PointF(it.x, it.y) } }
            val scale = base.width / dispW
            val keep = brushPx
            busy = true
            scope.launch {
                val res = runCatching {
                    withContext(Dispatchers.Default) { OfflineOps.erase(base, snapshot, scale, keep) }
                }
                res.onSuccess { out ->
                    commit(carry?.copy(bitmap = out) ?: EditState(out))
                    strokes.clear()
                }.onFailure { toast(ctx, it.message ?: "Erase nahi ho paya") }
                busy = false
            }
        } else {
            val argb = if (ai == AiTool.RemoveBg) 0 else bgColor.toArgb()
            busy = true
            scope.launch {
                OfflineOps.changeBackground(base, argb)
                    .onSuccess { out -> commit(carry?.copy(bitmap = out) ?: EditState(out)) }
                    .onFailure {
                        toast(
                            ctx,
                            "Background nahi hata paya. Pehli baar model download hota hai (internet chahiye), 1-2 minute baad dobara try karo."
                        )
                    }
                busy = false
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onClose) { Text("Cancel", color = Color.White, fontSize = 17.sp) }
            Box(Modifier.weight(1f))
            IconButton(onClick = { if (canUndo) { idx--; draft = null } }, enabled = canUndo) {
                Icon(Icons.Outlined.Undo, null, tint = Color.White, modifier = Modifier.alpha(if (canUndo) 1f else 0.35f))
            }
            IconButton(onClick = { if (canRedo) { idx++; draft = null } }, enabled = canRedo) {
                Icon(Icons.Outlined.Redo, null, tint = Color.White, modifier = Modifier.alpha(if (canRedo) 1f else 0.35f))
            }
            Box(Modifier.weight(1f))
            Text(
                "Save",
                color = Color.White,
                fontSize = 17.sp,
                modifier = Modifier
                    .alpha(if (dirty && !busy) 1f else 0.45f)
                    .bounceClick(enabled = dirty && !busy) { save() }
                    .clip50()
                    .background(Color(0xFF3A3A3A))
                    .padding(horizontal = 28.dp, vertical = 12.dp),
            )
        }

        // preview
        BoxWithConstraints(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 4.dp),
            contentAlignment = Alignment.Center,
        ) {
            if (loading) {
                CircularProgressIndicator(color = Color.White)
            } else if (shown == null) {
                Text("Image open nahi ho payi", color = Color.Gray)
            } else {
                val bmp = shown.bitmap
                val ar = bmp.width.toFloat() / bmp.height
                val w = if (maxWidth / maxHeight > ar) maxHeight * ar else maxWidth
                val h = w / ar
                val imageBitmap = remember(bmp) { bmp.asImageBitmap() }
                Box(Modifier.size(w, h).checker().onSizeChanged { dispW = it.width.toFloat().coerceAtLeast(1f) }) {
                    Crossfade(
                        targetState = imageBitmap,
                        modifier = Modifier.fillMaxSize(),
                        animationSpec = tween(320),
                        label = "editImage",
                    ) { ib ->
                        Image(
                            bitmap = ib,
                            contentDescription = null,
                            contentScale = ContentScale.FillBounds,
                            colorFilter = ColorFilter.colorMatrix(ColorMatrix(shown.matrixArray())),
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                    if (brushMode || strokes.isNotEmpty()) {
                        Canvas(
                            Modifier
                                .fillMaxSize()
                                .pointerInput(brushMode) {
                                    if (brushMode) detectTapGestures { strokes.add(listOf(it)) }
                                }
                                .pointerInput(brushMode) {
                                    if (brushMode) detectDragGestures(
                                        onDragStart = { current = listOf(it) },
                                        onDrag = { change, _ ->
                                            current = current + change.position
                                            change.consume()
                                        },
                                        onDragEnd = {
                                            if (current.isNotEmpty()) strokes.add(current)
                                            current = emptyList()
                                        },
                                        onDragCancel = { current = emptyList() },
                                    )
                                }
                        ) {
                            val style = Stroke(width = brushPx, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            (strokes.toList() + listOf(current)).forEach { pts ->
                                if (pts.isNotEmpty()) {
                                    val path = Path().apply {
                                        moveTo(pts[0].x, pts[0].y)
                                        if (pts.size == 1) lineTo(pts[0].x + 0.1f, pts[0].y)
                                        else for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
                                    }
                                    drawPath(path, Color(0x88FF3B30), style = style)
                                }
                            }
                        }
                    }
                    AnimatedVisibility(visible = busy, enter = fadeIn(tween(200)), exit = fadeOut(tween(250))) {
                        Box(Modifier.fillMaxSize().background(Color(0x88000000)), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    }
                }
            }
        }

        // tool panel
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    (fadeIn(tween(240)) + slideInVertically(tween(240)) { it / 5 }) togetherWith
                        fadeOut(tween(120))
                },
                label = "toolPanel",
            ) { t -> Column(Modifier.fillMaxWidth()) {
            when (t) {
                EditTab.Adjust -> {
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        Adj.entries.forEach { a -> ToolItem(a.icon, a.label, adj == a) { adj = a } }
                    }
                    if (shown != null) {
                        val value = when (adj) {
                            Adj.Exposure -> shown.exposure
                            Adj.Contrast -> shown.contrast
                            Adj.Saturation -> shown.saturation
                            Adj.Warmth -> shown.warmth
                        }
                        Slider(
                            value = value,
                            onValueChange = { v ->
                                draft = when (adj) {
                                    Adj.Exposure -> shown.copy(exposure = v)
                                    Adj.Contrast -> shown.copy(contrast = v)
                                    Adj.Saturation -> shown.copy(saturation = v)
                                    Adj.Warmth -> shown.copy(warmth = v)
                                }
                            },
                            onValueChangeFinished = { draft?.let { commit(it) } },
                            valueRange = -1f..1f,
                            colors = sliderColors(),
                        )
                    }
                }

                EditTab.Rotate -> {
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        ToolItem(Icons.Outlined.RotateLeft, "Rotate left", false) {
                            shown?.let { commit(it.copy(bitmap = rotateBitmap(it.bitmap, -90f))) }
                        }
                        ToolItem(Icons.Outlined.RotateRight, "Rotate right", false) {
                            shown?.let { commit(it.copy(bitmap = rotateBitmap(it.bitmap, 90f))) }
                        }
                        ToolItem(Icons.Outlined.Flip, "Flip", false) {
                            shown?.let { commit(it.copy(bitmap = flipBitmap(it.bitmap))) }
                        }
                    }
                }

                EditTab.Ai -> {
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        AiTool.entries.forEach { t -> ToolItem(t.icon, t.label, ai == t) { ai = t } }
                    }
                    AnimatedVisibility(
                        visible = ai == AiTool.Eraser,
                        enter = fadeIn(tween(200)) + expandVertically(),
                        exit = fadeOut(tween(120)) + shrinkVertically(),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Brush", color = Color.White, fontSize = 14.sp)
                            Slider(
                                value = brushDp,
                                onValueChange = { brushDp = it },
                                valueRange = 12f..80f,
                                colors = sliderColors(),
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            )
                            TextButton(onClick = { strokes.clear() }) { Text("Clear", color = Color.White) }
                        }
                    }
                    AnimatedVisibility(
                        visible = ai == AiTool.Background,
                        enter = fadeIn(tween(200)) + expandVertically(),
                        exit = fadeOut(tween(120)) + shrinkVertically(),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Color", color = Color.White, fontSize = 14.sp)
                            listOf(
                                Color.White, Color.Black, Color(0xFF9E9E9E),
                                Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFE53935),
                            ).forEach { c ->
                                Box(
                                    Modifier
                                        .size(if (bgColor == c) 34.dp else 28.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(c)
                                        .clickable { bgColor = c }
                                )
                            }
                        }
                    }
                    Button(
                        onClick = { runAi() },
                        enabled = !busy && shown != null,
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black,
                        ),
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    ) {
                        Crossfade(targetState = ai, animationSpec = tween(180), label = "aiBtn") { a ->
                            Text(
                                when (a) {
                                    AiTool.Eraser -> "Erase"
                                    AiTool.RemoveBg -> "Remove background"
                                    AiTool.Background -> "Change background"
                                }
                            )
                        }
                    }
                }
            }
            } }
        }

        // bottom pill
        Box(Modifier.fillMaxWidth().padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
            GlassPill {
                EditTab.entries.forEach { t ->
                    PillButton(t.icon, tab == t) {
                        tab = t
                        if (t != EditTab.Ai) strokes.clear()
                    }
                }
            }
        }
    }
}

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = Color.White,
    activeTrackColor = Color.White,
    inactiveTrackColor = Color(0x33FFFFFF),
)

private fun Modifier.clip50(): Modifier =
    this.then(Modifier.clip(RoundedCornerShape(50)))
