package com.ngallery.app

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

fun thumbReq(ctx: Context, uri: Uri, size: Int): ImageRequest =
    ImageRequest.Builder(ctx).data(uri).size(size).build()

@Composable
fun ScreenTitle(title: String, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 22.dp, end = 10.dp, top = 28.dp, bottom = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            fontFamily = Serif,
            fontSize = 40.sp,
            color = Color.White,
            modifier = Modifier.weight(1f),
        )
        trailing()
    }
}

private sealed interface Cell {
    data class Header(val text: String) : Cell
    data class Item(val media: Media, val index: Int) : Cell
}

private fun buildCells(media: List<Media>): List<Cell> {
    val out = ArrayList<Cell>(media.size + 32)
    var last = ""
    media.forEachIndexed { i, m ->
        val day = formatDay(m.dateMs)
        if (day != last) {
            out += Cell.Header(day)
            last = day
        }
        out += Cell.Item(m, i)
    }
    return out
}

@Composable
fun MediaGrid(
    media: List<Media>,
    onOpen: (Int) -> Unit,
    modifier: Modifier = Modifier,
    bottomPad: Dp = 0.dp,
    header: (@Composable () -> Unit)? = null,
) {
    val ctx = LocalContext.current
    val cells = remember(media) { buildCells(media) }
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = modifier,
        contentPadding = PaddingValues(bottom = bottomPad),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        if (header != null) {
            item(key = "header", span = { GridItemSpan(maxLineSpan) }) { header() }
        }
        items(
            cells,
            key = { c ->
                when (c) {
                    is Cell.Header -> "h" + c.text
                    is Cell.Item -> c.media.uri.toString()
                }
            },
            span = { c ->
                if (c is Cell.Header) GridItemSpan(maxLineSpan) else GridItemSpan(1)
            },
        ) { cell ->
            when (cell) {
                is Cell.Header -> Text(
                    cell.text,
                    color = Color.White,
                    fontSize = 19.sp,
                    modifier = Modifier.padding(start = 18.dp, top = 22.dp, bottom = 10.dp),
                )
                is Cell.Item -> {
                    val m = cell.media
                    Box(
                        Modifier
                            .aspectRatio(1f)
                            .clickable { onOpen(cell.index) }
                    ) {
                        AsyncImage(
                            model = remember(m.uri) { thumbReq(ctx, m.uri, 360) },
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                        if (m.isVideo) {
                            Text(
                                formatDuration(m.durationMs),
                                color = Color.White,
                                fontFamily = Mono,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0x99000000))
                                    .padding(horizontal = 7.dp, vertical = 2.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

private enum class MediaFilter(val label: String) { All("All"), Photos("Photos"), Videos("Videos") }

@Composable
fun PhotosScreen(
    media: List<Media>,
    onOpen: (List<Media>, Int) -> Unit,
    onSettings: () -> Unit,
) {
    var filter by remember { mutableStateOf(MediaFilter.All) }
    var filterMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    val shown = remember(media, filter) {
        when (filter) {
            MediaFilter.All -> media
            MediaFilter.Photos -> media.filter { !it.isVideo }
            MediaFilter.Videos -> media.filter { it.isVideo }
        }
    }
    MediaGrid(
        media = shown,
        onOpen = { onOpen(shown, it) },
        modifier = Modifier.fillMaxSize(),
        bottomPad = 120.dp,
        header = {
            ScreenTitle("Photos") {
                Box {
                    IconButton(onClick = { filterMenu = true }) {
                        Icon(Icons.Outlined.FilterList, null, tint = Color.White)
                    }
                    DropdownMenu(expanded = filterMenu, onDismissRequest = { filterMenu = false }) {
                        MediaFilter.entries.forEach { f ->
                            DropdownMenuItem(
                                text = { Text(f.label) },
                                onClick = { filter = f; filterMenu = false },
                            )
                        }
                    }
                }
                Box {
                    IconButton(onClick = { moreMenu = true }) {
                        Icon(Icons.Outlined.MoreVert, null, tint = Color.White)
                    }
                    DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = { moreMenu = false; onSettings() },
                        )
                    }
                }
            }
        },
    )
}

private data class Album(val name: String, val items: List<Media>)

@Composable
fun AlbumsScreen(media: List<Media>, onOpen: (String, List<Media>) -> Unit) {
    val ctx = LocalContext.current
    val albums = remember(media) {
        media.groupBy { it.bucket }
            .map { (n, l) -> Album(n, l) }
            .sortedByDescending { it.items.size }
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(6),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 130.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { ScreenTitle("Albums") }
        itemsIndexed(
            albums,
            key = { _, a -> a.name },
            span = { i, _ -> GridItemSpan(if (i < 2) 3 else 2) },
        ) { i, a ->
            val big = i < 2
            Column(
                Modifier
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF121212))
                    .clickable { onOpen(a.name, a.items) }
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AsyncImage(
                    model = remember(a.items.first().uri) { thumbReq(ctx, a.items.first().uri, 500) },
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(if (big) 0.95f else 0.8f)
                        .clip(RoundedCornerShape(22.dp)),
                )
                Text(
                    a.name,
                    color = Color.White,
                    fontSize = if (big) 22.sp else 15.sp,
                    maxLines = 1,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 12.dp),
                )
                Text(
                    "%,d".format(a.items.size),
                    color = Color(0xFF8A8A8A),
                    fontFamily = Mono,
                    fontSize = if (big) 16.sp else 13.sp,
                    modifier = Modifier.padding(bottom = 10.dp, top = 2.dp),
                )
            }
        }
    }
}

private data class Category(val title: String, val items: List<Media>)

@Composable
fun ExploreScreen(
    media: List<Media>,
    favorites: Set<String>,
    onOpenViewer: (List<Media>, Int) -> Unit,
    onOpenCollection: (String, List<Media>) -> Unit,
) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val results = remember(media, q) {
        if (q.isBlank()) emptyList()
        else media.filter {
            it.name.contains(q, true) || it.bucket.contains(q, true) ||
                formatDay(it.dateMs).contains(q, true)
        }
    }
    val categories = remember(media, favorites) {
        listOf(
            Category("Photos", media.filter { !it.isVideo }),
            Category("Videos", media.filter { it.isVideo }),
            Category("Screenshots", media.filter { it.bucket.contains("screenshot", true) }),
            Category("Favorites", media.filter { it.uri.toString() in favorites }),
        ).filter { it.items.isNotEmpty() }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Explore")
        TextField(
            value = q,
            onValueChange = { q = it },
            singleLine = true,
            placeholder = { Text("Search your Gallery…", color = Color(0xFF7A7A7A)) },
            leadingIcon = { Icon(Icons.Outlined.Search, null, tint = Color.White) },
            shape = RoundedCornerShape(50),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF1A1A1A),
                unfocusedContainerColor = Color(0xFF1A1A1A),
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = Color.White,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        )
        if (q.isBlank()) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 130.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(categories, key = { it.title }) { c ->
                    Column(
                        Modifier
                            .clip(RoundedCornerShape(28.dp))
                            .background(Color(0xFF121212))
                            .clickable { onOpenCollection(c.title, c.items) }
                            .padding(8.dp)
                    ) {
                        AsyncImage(
                            model = remember(c.items.first().uri) { thumbReq(ctx, c.items.first().uri, 500) },
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1.2f)
                                .clip(RoundedCornerShape(22.dp)),
                        )
                        Row(
                            Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(c.title, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
                            Text(
                                "${c.items.size}",
                                color = Color(0xFF8A8A8A),
                                fontFamily = Mono,
                                fontSize = 14.sp,
                            )
                        }
                    }
                }
            }
        } else {
            MediaGrid(
                media = results,
                onOpen = { onOpenViewer(results, it) },
                modifier = Modifier.weight(1f),
                bottomPad = 130.dp,
            )
        }
    }
}
